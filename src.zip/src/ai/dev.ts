import { config } from 'dotenv';
config();

import '@/ai/flows/validate-yaml-configuration.ts';